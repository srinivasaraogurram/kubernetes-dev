This Git repository contains supporting files for all editions of my "Getting Started with Kubernetes" video course. See https://sandervanvugt.com for more details. It is also used in the "Kubernetes in 4 Hours" live training I'm teaching at https://learning.oreilly.com.

Read the SetupGuide.pdf document in this Git repository for additional course setup instructions.
